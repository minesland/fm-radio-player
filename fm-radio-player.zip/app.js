const apiBase = 'https://de1.api.radio-browser.info/json';
const countrySelect = document.getElementById('countrySelect');
const stationsContainer = document.getElementById('stationsContainer');
const audio = document.getElementById('audioPlayer');
const nowPlaying = document.getElementById('nowPlaying');
const searchInput = document.getElementById('searchInput');

const favoritesBtn = document.getElementById('favoritesBtn');
const exportBtn = document.getElementById('exportBtn');
const importBtn = document.getElementById('importBtn');
const importFile = document.getElementById('importFile');
const volumeSlider = document.getElementById('volumeSlider');

let stations = [];
let favorites = JSON.parse(localStorage.getItem('fm_radio_favorites') || '[]');
let showingFavorites = false;

async function loadCountries() {
  const res = await fetch(`${apiBase}/countries`);
  const data = await res.json();
  data.sort((a,b)=>a.name.localeCompare(b.name));
  data.forEach(c=>{
    const opt = document.createElement('option');
    opt.value = c.name;
    opt.textContent = c.name;
    countrySelect.appendChild(opt);
  });
}

async function loadStations(country) {
  stationsContainer.innerHTML = `<p class="loading">Loading ${country} stations...</p>`;
  const res = await fetch(`${apiBase}/stations/bycountry/${encodeURIComponent(country)}`);
  stations = await res.json();
  renderStations(stations);
}

function renderStations(list) {
  stationsContainer.innerHTML = '';
  if (!list.length) {
    stationsContainer.innerHTML = `<p class="loading">No stations found.</p>`;
    return;
  }
  list.forEach(st => {
    const card = document.createElement('div');
    card.className = 'station';
    card.innerHTML = `
      <img src="${st.favicon || 'assets/default-logo.png'}" alt="">
      <div>${st.name}</div>
    `;
    const favBtn = document.createElement('button');
    favBtn.className = 'fav-btn';
    favBtn.textContent = isFavorite(st) ? '★' : '☆';
    favBtn.addEventListener('click', e => {
      e.stopPropagation();
      toggleFavorite(st);
      favBtn.textContent = isFavorite(st) ? '★' : '☆';
    });
    card.appendChild(favBtn);

    card.addEventListener('click', () => playStation(st));
    stationsContainer.appendChild(card);
  });
}

function playStation(st) {
  audio.src = st.url_resolved;
  audio.play().catch(()=>{});
  nowPlaying.textContent = `▶ ${st.name}`;
  localStorage.setItem('last_station', JSON.stringify(st));
}

function toggleFavorite(st) {
  const idx = favorites.findIndex(x => x.stationuuid === st.stationuuid);
  if (idx >= 0) favorites.splice(idx, 1);
  else favorites.push(st);
  localStorage.setItem('fm_radio_favorites', JSON.stringify(favorites));
}

function isFavorite(st) {
  return favorites.some(x => x.stationuuid === st.stationuuid);
}

favoritesBtn.addEventListener('click', () => {
  showingFavorites = !showingFavorites;
  favoritesBtn.textContent = showingFavorites ? '📻 All' : '⭐ Favorites';
  renderStations(showingFavorites ? favorites : stations);
});

searchInput.addEventListener('input', e => {
  const term = e.target.value.toLowerCase();
  const filtered = (showingFavorites ? favorites : stations)
    .filter(st => st.name.toLowerCase().includes(term));
  renderStations(filtered);
});

exportBtn.addEventListener('click', () => {
  const blob = new Blob([JSON.stringify(favorites, null, 2)], {type:'application/json'});
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = 'favorites.json';
  a.click();
});

importBtn.addEventListener('click', () => importFile.click());
importFile.addEventListener('change', e => {
  const file = e.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = () => {
    try {
      favorites = JSON.parse(reader.result);
      localStorage.setItem('fm_radio_favorites', JSON.stringify(favorites));
      alert('Favorites imported!');
      if (showingFavorites) renderStations(favorites);
    } catch {
      alert('Invalid JSON file.');
    }
  };
  reader.readAsText(file);
});

volumeSlider.addEventListener('input', e => {
  audio.volume = parseFloat(e.target.value);
  localStorage.setItem('fm_radio_volume', e.target.value);
});

window.addEventListener('DOMContentLoaded', async () => {
  await loadCountries();
  const lastVol = localStorage.getItem('fm_radio_volume');
  if (lastVol) {
    audio.volume = parseFloat(lastVol);
    volumeSlider.value = lastVol;
  }
  const lastSt = localStorage.getItem('last_station');
  if (lastSt) {
    const st = JSON.parse(lastSt);
    nowPlaying.textContent = `▶ ${st.name}`;
    audio.src = st.url_resolved;
  }
});

countrySelect.addEventListener('change', e => {
  if (e.target.value) loadStations(e.target.value);
});
